from django.apps import AppConfig


class HardwareConfig(AppConfig):
    name = 'hardware'
